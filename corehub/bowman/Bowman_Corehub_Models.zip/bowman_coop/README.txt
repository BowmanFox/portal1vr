Bowman character assets for the native 2009 Corehub prototype.
This package does not include a VR runtime: Corehub VR support is unfinished.
Launch Bowman Co-op.cmd starts the separate model profile on mp_coop_start.
All maps opened in this profile use these models. The normal launch stays separate.
The original player_animations.mdl is loaded from your existing installation.
Blender facial shape keys are preserved in the source but not exported as Source flexes.
