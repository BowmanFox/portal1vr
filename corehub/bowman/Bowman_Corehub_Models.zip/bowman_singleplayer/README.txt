Portal 1 Bowman appearance with the updated mesh, adapted for native Corehub.
Launch Bowman Single-player.cmd, then choose New Game or load a save.
This character package does not include VR support or Source facial flexes.
Co-op colors are available in the separate co-op launch profile.
